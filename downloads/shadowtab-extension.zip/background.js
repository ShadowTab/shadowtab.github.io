// background.js

// Initialize bookmarks storage
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.sync.set({ bookmarks: [] });
});
